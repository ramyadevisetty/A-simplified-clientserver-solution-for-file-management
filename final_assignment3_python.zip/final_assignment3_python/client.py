"""
This is an application of client
"""
import asyncio

async def clients_tcp(message):
    """
    Establishment of connection
    """
    reader, writer = await asyncio.open_connection(
        '127.0.0.1', 8888)

    print('Send {!r}'.format(message))
    while True:
        print("Type '1' or '2'\n1: Register\n2: Login")
        try:
            input_val = int(input("Type option '1' or '2':"))
        except ValueError:
            print("you can only use int value")
            continue
        if input_val == 1:
            print("----------REGISTER PAGE---------")
            access_id = input('Type access_id: ')
            access_code = input('Type access_code: ')
            details = str('1 {} {}'.format(access_id, access_code))
            print(details)
            writer.write(details.encode())
        elif input_val == 2:
            print("-----------LOGIN PAGE------------")
            access_id = input('Type access_id: ')
            access_code = input('Type access_code: ')
            details = str('2 {} {}'.format(access_id, access_code))
            print(details)
            writer.write(details.encode())
        else:
            print("input is wrong")
            continue
        data = await reader.read(5000)
        response = data.decode()
        if response == 'registration successful':
            print('registeration is done successfully')
            break
        elif response == 'login successful':
            print('login done successfully')
            break
        elif response == 'wrong credentials':
            print('wrong credentials, login is not done')
            continue
        elif response == 'exist':
            print('existing user')
            continue
        elif response == 'logedin previously':
            print('logedin previously')
            continue
        elif response == 'wrong command':
            print('incorrect command')

    while True:
        print("type 'commands' for guidance")
        request = input('>>>>')
        if request == 'quit':
            writer.write('quit'.encode())
            break
        elif request == 'commands':
            print(
"""1.change_folder <folder_name>:
	Move the current working directory for the current user to the
    specified folder residing in the current folder.
	If the <folder_name> does not point to a folder
    in the current working directory, the request is to be denied
    with a proper message highlighting the error for the user.

2.list:
	Prints all the files in the current working directory
    with their size and date of modification.

3.read_file<file_name>:
	Read data from the file <file_name> in the current working directory
    for the user issuing the request and return the first hundred characters in it.
    Each subsequent call by the same client is to return the next hundred
	characters in the file, up until all characters are read.
    If a file with the specified <file_name> does not exist
	in the current working directory for the user,
    the request is to be denied with a proper message highlighting
	the error for the user.

4.write_file<file_name><input>:
	Write the data in <input> to the end of the file <file_name>
     in the current working directory for the user issuing
	the request, starting on a new line.  If no file exists with the given <file_name>,
    a new file is to be created
	in the current working directory for the user.

5.create_folder<folder_name>:
	Create a new folder with the specified <folder_name> in the
    current working directory for the user issuing the request.
	If a folder with the given name already exists,
    the request is to be denied with a proper message
    highlighting the error for the user.

6.register<access_id><access_code><privileges>:
	Register a new user with username and access_code.
    If the username or access_code already exists then it returns an error.
	<privileges> can either be a user or an admin.

7.login<access_id><access_code>:
	Log in the user conforming with <access_id> onto the server
    if the <access_code> provided matches the access_code used while
	registering. If the <access_code> does not match or
    if the <access_id> does not exist, an error message should be returned
	to the request for the client to present to the user.

8.Quit:
	Logout the user, close the connection to the server,
    and close the application."""
            )
            continue
        elif request == '':
            continue
        else:
            writer.write(request.encode())
            data1 = await reader.read(5000)
            print(f'{data1.decode()}')
            continue
    print('close the connection')
    writer.close()
    await writer.wait_closed()
try:
    asyncio.run(clients_tcp('successful connection'))
except ConnectionRefusedError:
    print("Connection failed")
    