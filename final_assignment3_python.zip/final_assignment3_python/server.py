"""Server starts serving from here"""
import asyncio
import signal
from server_logic import Server

signal.signal(signal.SIGINT, signal.SIG_DFL)
users_connected = {}

async def clients_comm(reader, writer):
    """
        The server is set up and is waiting for the client to bind.
        Multiple clients can bind to this server.

        arguments
        *************
        writer (obj): StreamReader
        reader (obj): StreamReader
    """
    response = "successful connection"
    know = writer.get_extra_info('peername')
    users_connected[know[1]] = Server()
    print("{} is connected to server".format(know))

    while True:
        res = await reader.read(5000)
        response = res.decode().strip()
        if response == 'quit':
            users_connected[know[1]].clear_log()
            break
        print("received {} request from {}".format(response,know))
        reply = users_connected[know[1]].partition_data(response)
        print("response from the server: '{}'".format(reply))
        if reply != '':
            writer.write(reply.encode())
        elif reply != 'None':
            writer.write(reply.encode())
        elif reply == '.':
            writer.write(reply.encode())
        await writer.drain()

    print("close the connection")
    writer.close()

async def main():
    """
        This is the main function where the server creation begins.
    """
    ip_no = '127.0.0.1'
    port_no = '8888'
    server = await asyncio.start_server(clients_comm, ip_no, port_no)
    know = server.sockets[0].getsockname()
    print('Serving on {}'.format(know))
    async with server:
        await server.serve_forever()

asyncio.run(main())
