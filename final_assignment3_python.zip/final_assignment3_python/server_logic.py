""" User feedback is received, and methods are carried out based on it."""
import os
import time
import datetime
from os import scandir

class Server():
    """
    A class that handles all of the logic for user-input commands.

    Attributes
    ************
    response (str)        : It saves the command entered by the user.
    id (str)              : It saves the user's entered id.
    pwd (str)             : It saves the pwd entered by the user.
    index1 (str)          : It shows where the characters are read from the file when the read file command is used.
    index2 (int)          : It shows where the characters reading from the file ended when the read file command was entered.
    variable (int)        : After he/she loged in/registered, the variable becomes 1 that can not be logedin again until user decides to quit.
    _root_directory(str)  : It saves the root directory
    active_directory (str): When a user registers and performs those actions,It can be modified.

    """
    def __init__(self):
        """
        This function intializes all of the program's required attributes.

        """
        self.response = ''
        self.id = ''
        self.pwd = ''
        self.index1 = -100
        self.index2 = 0
        self._root_directory = os.path.dirname(os.path.abspath(__file__))
        self.active_directory = ''
        self.sub = 0

    def partition_data(self, response):
        """
            This function partitions the answer into a list of objects.
            It switches to another method based on the answer.

            Arguments
            *************
            response : The user given command.
        """
        self.response = response
        partition_list = []
        temporary = ''
        for tmp in self.response:
            if tmp == ' ':
                partition_list.append(temporary)
                temporary = ''
            else:
                temporary += tmp
        if temporary:
            partition_list.append(temporary)

        if partition_list[0] == '1':
            print(partition_list)
            reply = self.register(partition_list)
            return reply

        if partition_list[0] == '2':
            try:
                reply = self.login(partition_list)
            except:
                reply = 'ERROR'
            return reply

        if partition_list[0] == 'create_folder':
            try:
                reply = self.create_folder(partition_list)
            except:
                reply = 'ERROR'
            return reply

        if self.response == 'list':
            try:
                reply = self.list()
            except:

                reply = 'ERROR'
            return reply

        if partition_list[0] == 'read_file':
            try:
                reply = self.read_file(partition_list)
            except:
                reply = 'ERROR'
            return reply

        if partition_list[0] == 'write_file':
            try:
                reply = self.write_file(partition_list)
            except:
                reply = 'ERROR'
            return reply

        if partition_list[0] == 'change_folder':
            try:
                reply = self.change_folder(partition_list)
            except:
                reply = 'ERROR'
            return reply
        return 'wrong command'

    def register(self, partition_list):
        """
            This function registers and logs in the user.

            Arguments
            *************
            partition_list : This is the partion list of containing commands.
        """
        variable = partition_list[0]
        if variable == '1':
            if self.check_user(partition_list) == 'exist':
                return 'exist'
            try:
                self.id = partition_list[1]
                self.pwd = partition_list[2]
            except IndexError:
                return 'Enter id and pwd'
            files = os.path.join(self.active_directory, 'registered_users.txt')
            with open (files, 'a') as file:
                details = str(f'\n{self.id},{self.pwd}')
                file.writelines(details)
            directory = os.path.join(self._root_directory, self.id)
            self.active_directory = os.mkdir(directory)
            text_file = os.path.join(directory, 'text_file.txt' )
            open_text_file = open(text_file, 'x')
            open_text_file.close()
            partition_list = ['2', self.id, self.pwd]
            outcome = self.login(partition_list)
            return outcome

    def login(self, partition_list):
        """
            This function logs in the user.

            Arguments
            **************
            partition_list : The partition list of containing commands.
        """
        variable = partition_list[0]
        try:
            self.id = partition_list[1]
            self.pwd = partition_list[2]
        except IndexError:
            return 'Enter id and pwd'
        if variable == '2':
            scan = str(f'{partition_list[1]},{partition_list[2]}')
            self.active_directory = self._root_directory
            filea = os.path.join(self.active_directory, 'registered_users.txt')
            with open(filea,"r") as scan_file:
                for tmp in scan_file:
                    tmp_1 = tmp.strip()
                    if tmp_1 == scan:
                        self.active_directory = self._root_directory
                        file = os.path.join(self.active_directory, 'logined_users.txt')
                        with open(file,"r") as r_file:
                            r_lines = r_file.readlines()
                            if self.id in r_lines:
                                return 'logedin previously'
                        file1 = os.path.join(self.active_directory, 'logined_users.txt')
                        with open(file1,"a+") as join_file:
                            join_file.writelines(str('\n{}'.format(self.id)))
                            self.active_directory = str(f'{self._root_directory}''\\'f'{self.id}')
                            os.chdir(self.active_directory)
                            return 'login successful'
                return "wrong credentials"

    def create_folder(self, partition_list):
        """
            This function creates new folder with the name provided by the logedin user.
            The directory will not be shifted either.

            Arguments
            *************
            partition_list : The partition list of containing commands.
        """
        value = os.path.join(os.path.dirname(os.path.abspath(__file__)), self.id)
        value2 = str(f'{value}''//'f'{partition_list[1]}')
        if os.path.exists(value2):
            return 'existing folder'
        os.mkdir(value2)
        return 'creation of folder successful'

    def list(self):
        """
            This function returns a list of all the files and directories in that directory.
        """
        outcome1 = ''
        sub_dir = scandir(self.active_directory)
        for tmp in sub_dir:
            data1 = os.path.getctime(tmp)
            data = time.ctime(data1)
            date_time = datetime.datetime.strptime(data, "%c")
            size = os.path.getsize(tmp)
            outcome1 = outcome1 + str(f'{tmp.name} \t\t {size} \t\t {date_time}\n')
        return outcome1

    def read_file(self, partition_list):
        """
            This function reads Up to 100 characters from a file.
            Return the very next 100 characters for each subsequent call from the same user.

            Arguments
            *************
            partition_list : The partition list of containing commands.
        """
        self.active_directory = self._root_directory
        file_path = os.path.join(self._root_directory, self.id, partition_list[1])
        try:
            path = str(f'{self.active_directory}\\{self.id}\\{partition_list[1]}')
            if(os.path.exists(path)):
                with open(path, 'r') as readfile:
                    print(readfile)
                    variable = readfile.read()
                    variable1 = len(variable)
                    print(variable1)
            else:
                return 'given file name is not in existing'        
        except IndexError:
            self.index1 = -100
            self.index2 = 0
            return "The file's name should be specified"
        except Exception:
            self.index1 = -100
            self.index2 = 0
            return "The file's name should be specified"
        self.sub = (variable1-self.index2)
        print(path)
        while os.path.exists(path):
            if variable1 != self.index2:
                if self.sub > 100:
                    self.index1 += 100
                    self.index2 += 100
                    result = str(variable[self.index1:self.index2])
                    return result
                elif self.sub <= 100:
                    self.index1 += 100
                    self.index2 = variable1
                    result = str(variable[self.index1:len(variable)])
                    return result
                break
            else:
                return "Reading file is finished."

    def write_file(self, partition_list):
        """
            This function writtens the user's input to the file that the user has specified.

            Arguments
            **************
            partition_list : The partition list of containing commands.
        """
        self.active_directory = os.path.join(self._root_directory, self.id)
        file_path = os.path.join(self._root_directory, self.id, partition_list[1])
        try:
            with open(file_path, 'a') as writefile:
                try:
                    details = ''
                    if not partition_list[2]:
                        writefile.seek(0)
                        writefile.truncate()
                        return "contents in the file is cleared" 
                    for i in range(2, len(partition_list)):
                        details = details+ partition_list[i]+' '
                        print(partition_list)
                        details1 = [details, '\n']
                except IndexError:
                    writefile.seek(0)
                    writefile.truncate()
                    return "contents in the file is cleared"
                writefile.writelines(details1)
                return "successfully written in the file"
        except IndexError:
            return 'Name of the file must be specified'

    def change_folder(self, partition_list):
        """
            This function will change the user's directory;
            the folder must remain in the same directory.

            Arguments
            *************
            partition_list : The partition list of containing commands.
        """
        try:
            if partition_list[1] == '..':
                if self.active_directory == self._root_directory:
                    return 'access denied'
                else:
                    os.chdir('../')
                    self.active_directory = os.getcwd()
                    return f'Directory is changed to {self.active_directory}'
        except IndexError:
            return "It is necessary to include the folder's name."

        try:
            path = str(f'{self.active_directory}''\\'f'{partition_list[1]}')
            if os.path.exists(path) and partition_list[1]!='..':
                if self.active_directory != self._root_directory:
                    os.chdir(path)
                    self.active_directory = os.getcwd()
                    return f'Directory is changed to {self.active_directory}'
                elif self.active_directory == self._root_directory:
                    if partition_list[1] == self.id:
                        os.chdir(path)
                        self.active_directory = os.getcwd()
                        return f'Directory is changed to {self.active_directory}'
                    else:
                        return "You are unable to access another User's folder."
            else:
                return "no folder found with this name"
        except IndexError:
            return "It is necessary to include the folder's name."
        

    def check_user(self, partition_list):
        """
            This function checks whether the user exists in the logined_users file.

            Arguments
            **************
            partition_list : The partition list of containing commands.
        """
        self.active_directory = self._root_directory
        print(self._root_directory)
        filem = os.path.join(self.active_directory, 'registered_users.txt')
        with open(filem,"r") as file:
            for tmp in file:
                tmp_strip = tmp.strip()
                tmp_1 = tmp_strip.split(',', 1)
                try:
                    if tmp_1[0] == partition_list[1]:
                        return 'exist'
                except IndexError:
                    return 'enter id and pwd'
            return 'ok'

    def clear_log(self):
        """
            This function removes the user from the logined_users file,
            When the user enters the quit command.
        """
        os.chdir(self._root_directory)
        print(self._root_directory)
        print(os.getcwd())
        rem_file = open('logined_users.txt', 'r')
        rem_file_data = rem_file.read()
        rem_file.close()
        data = rem_file_data.replace(self.id, '')
        files = open('logined_users.txt', 'w')
        files.write(data)
        files.close()
