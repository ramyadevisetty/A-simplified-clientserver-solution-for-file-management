"Testing done here"
import os
import unittest
from server_logic import Server

class Tester(unittest.TestCase):
    """
    This class performs a unit test with the data provided.
    """

    def test_read_file(self):
        """
        The read_file service is tested using this method in a variety of cases.
        """
        test = Server()
        test.active_directory = os.getcwd()
        data = [['read_file','practice_file.txt'],['read_file', ''], ['read_file', 'practice_file.txt'], ['read_file', 'testing_file.txt']]
        reply = ['Hello my name is ramya Probably the most effective way to achieve paragraph unity is to express the ',"The file's name should be specified",'Hello my name is ramya Probably the most effective way to achieve paragraph unity is to express the ','given file name is not in existing']
        result = []
        for variable in data:
            result.append(test.read_file(variable))
        self.assertListEqual(result, reply)

    def test_write_file(self):
        """
        The write_file service is tested using this method in a variety of cases.
        """
        test = Server()
        test.active_directory = os.getcwd()
        data = [['write_file', 'practice_file.txt',],['write_file', 'practice_file', 'hello']]
        reply = ["contents in the file is cleared", "successfully written in the file"]
        result = []
        for variable in data:
            result.append(test.write_file(variable))
        print(reply)
        print(result)
        self.assertListEqual(result, reply)

    def test_create_folder(self):
        """
        The create_folder service is tested using this method in a variety of cases
        """
        test = Server()
        data = [['create_folder','new_test_folder'], ['create_folder','new_test_folder']]
        reply = ['creation of folder successful','existing folder']
        result = []
        for variable in data:
            result.append(test.create_folder(variable))
        self.assertListEqual(result, reply)

    def test_change_folder(self):
        """
        The change_folder service is tested using this method in a variety of cases
        """
        test = Server()
        test.id = 'new_folder'
        test.active_directory = os.getcwd()
        test._root_directory = os.getcwd()
        data = [['change_folder', 'new_folder'], ['change_folder', 'name'],['change_folder', 'name'],
        ['change_folder', '..'],['change_folder', '..'],['change_folder', '..']]
        link = os.path.join(os.getcwd(), 'new_folder')
        link1 = os.path.join(link, 'name')
        link2 = os.path.normpath(link1 + os.sep + os.pardir)
        link3 = os.path.normpath(link2 + os.sep + os.pardir)
        reply = ['Directory is changed to {}'.format(link),'Directory is changed to {}'.format(link1),'no folder found with this name',
        'Directory is changed to {}'.format(link2),'Directory is changed to {}'.format(link3),'access denied']
        result = []
        for variable in data:
            result.append(test.change_folder(variable))
        print(result)
        print(reply)
        self.assertListEqual(result, reply)

if __name__ == '__main__':
    unittest.main()
